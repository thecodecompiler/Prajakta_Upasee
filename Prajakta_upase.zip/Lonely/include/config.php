<?php

$dbname = "portfolio";
$dbuser = "root";
$dbpass = "";
$dbhost = "localhost";

$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

if (mysqli_connect_errno()) {
    printf("", mysqli_connect_error());
    exit(1);
}


?>
<?php include "include/config.php";

$sql = "select * from users where users.id =1";
$result = mysqli_query($conn, $sql);
$data = mysqli_fetch_assoc($result);
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Prajakta upase</title>
  <meta name="description" content="">
  <meta name="keywords" content="">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Playfair+Display:ital,wght@0,400;0,500;0,600;0,700;0,800;0,900;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Lonely
  * Template URL: https://bootstrapmade.com/free-html-bootstrap-template-lonely/
  * Updated: Aug 07 2024 with Bootstrap v5.3.3
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body class="index-page">

  <header id="header" class="header d-flex align-items-center sticky-top">
    <div class="container-fluid container-xl position-relative d-flex align-items-center justify-content-between">

      <a href="index.html" class="logo d-flex align-items-center">
        <!-- Uncomment the line below if you also wish to use an image logo -->
        <!-- <img src="assets/img/logo.png" alt=""> -->
        <h1 class="sitename">Portfolio</h1>
      </a>

      <nav id="navmenu" class="navmenu">
        <ul>
        <li><a href="#hero" class="active">Home</a></li>
        <li><a href="#about">About</a></li>
        <li><a href="#Skills">Skills</a></li>
        <li><a href="#resume">Resume</a></li>
        <li><a href="#Internship">Internship</a></li>
       <li><a href="#contact"> Contact</a></li>
       
       <li><img id="toggle-image" src="assets/img/icon1.png" alt="Toggle Dark Mode" style="cursor: pointer; width: 30px;">
       </li>
        </ul>
        <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
        
      </nav>
    </div>
  </header>

  <main class="main">

    <!-- Hero Section -->
    <section id="hero" class="hero section dark-background">
    <img src="assets/img/images.jpeg" alt="" data-aos="fade-in" class="">

      <div class="container text-center" data-aos="fade-up" data-aos-delay="100">
        <h2>Hi ,I'm </h2>
        <h3><?php  echo " $data[name] " ?></h3>
        <p><?php  echo " $data[title] " ?><br></p>
        <a href="#about" class="btn-scroll" title="Scroll Down"><i class="bi bi-chevron-down"></i></a>
      </div>

    </section><!-- /Hero Section -->

    <!-- About Section -->
    <section id="about" class="about section">

      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <h2>About</h2>
      </div><!-- End Section Title -->

      <div class="container" data-aos="fade-up" data-aos-delay="100">

        <div class="row gy-4 justify-content-center">
          <div class="col-lg-4">
            <img src="assets/img/image.png" class="img-fluid" alt="">
          </div>
          <div class="col-lg-8 content">
            <h2><?php  echo " $data[title] " ?></h2>
            <br>
            <div class="row">
              <div class="col-lg-6">
                <ul>
                  <li><i class="bi bi-chevron-right"></i> <strong>Birthday:</strong> <span><?php echo "$data[date]"?></span></li>
                  <li><i class="bi bi-chevron-right"></i> <strong>Phone:</strong> <span><?php echo "$data[phone]"?></span></li>
                  <li><i class="bi bi-chevron-right"></i> <strong>City:</strong> <span><?php echo "$data[place]"?></span></li>
                </ul>
              </div>
              <div class="col-lg-6">
                <ul>
                  <li><i class="bi bi-chevron-right"></i> <strong>Age:</strong> <span><?php echo "$data[age]"?></span></li>
                  <li><i class="bi bi-chevron-right"></i> <strong>Degree:</strong> <span><?php echo "$data[Degree]"?></span></li>
                  <li><i class="bi bi-chevron-right"></i> <strong>Email:</strong> <span><?php echo "$data[email]"?></span></li>
                                 </ul>
              </div>
            </div>
            <p class="py-3">
            With a deep-rooted love for coding, I thrive on turning complex problems into elegant, user-friendly applications. My journey into the world of programming began with a burning curiosity and an insatiable desire to learn. Over the years, I have honed my skills and gained expertise in various programming languages, frameworks, and technologies.</>

          </div>
        </div>

      </div>

    </section><!-- /About Section -->

    <!-- Skills Section -->
    <section id="Skills" class="skills section">

      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <h2>Skills</h2>
      </div><!-- End Section Title -->

      <div class="container" data-aos="fade-up" data-aos-delay="100">

        <div class="row skills-content skills-animation">

          <div class="col-lg-6">

            <div class="progress">
              <span class="skill"><span>HTML</span> <i class="val">100%</i></span>
              <div class="progress-bar-wrap">
                <div class="progress-bar" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
            </div><!-- End Skills Item -->

            <div class="progress">
              <span class="skill"><span>CSS</span> <i class="val">90%</i></span>
              <div class="progress-bar-wrap">
                <div class="progress-bar" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
            </div><!-- End Skills Item -->

            <div class="progress">
              <span class="skill"><span>JavaScript</span> <i class="val">75%</i></span>
              <div class="progress-bar-wrap">
                <div class="progress-bar" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
            </div><!-- End Skills Item -->

          </div>

          <div class="col-lg-6">

            <div class="progress">
              <span class="skill"><span>PHP</span> <i class="val">90%</i></span>
              <div class="progress-bar-wrap">
                <div class="progress-bar" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
            </div><!-- End Skills Item -->

            <div class="progress">
              <span class="skill"><span>Python/span> <i class="val">95%</i></span>
              <div class="progress-bar-wrap">
                <div class="progress-bar" role="progressbar" aria-valuenow="95" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
            </div><!-- End Skills Item -->

            
          </div>

        </div>

      </div>

    </section><!-- /Skills Section -->

    <!-- Resume Section -->
    <section id="resume" class="resume section">

      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <h2>Resume</h2>
      

      <div class="container">

        <div class="row">

          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">
            <h3 class="resume-title">Sumary</h3>

            <div class="resume-item pb-0">
              <h4><?php echo "$data[name]"?></h4>
              <p><em>I'm a passionate programmer dedicated to creating innovative and efficient solutions.</em></p>
              <ul>
                <li><?php echo "$data[address]"?></li>
                <li><?php echo "$data[phone]"?></li>
                <li><?php echo "$data[email]"?></li>
              </ul>
            </div><!-- Edn Resume Item -->

            <h3 class="resume-title">Education</h3>
            <div class="resume-item">
              <h4>HSC (computer Science) </h4>
              <h5>June 2018 - May 2020</h5>
              <p><em>Ramniranjan Junjunwala College of arts ,commerce & science ghatkopar</em></p>
            </div><!-- Edn Resume Item -->

            <div class="resume-item">
              <h4>B.E. In Computer Engineering</h4>
              <h5>June 2020 - May 2024</h5>
              <p><em>M.H. Saboo Siddik College of Engineering , Byculla</em></p>
            </div><!-- Edn Resume Item -->

            
            </div><!-- Edn Resume Item -->

           
          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="200">
            <h2 class="resume-title">PROJECTS            </h2>
            <div class="resume-item">
              <h3>Smart Resume Analyzer | Python (NLP)              </h3>
              <ul>
<p>A smart resume analyzer project using NLP could involve training a model to automatically extract relevant information
from resumes, such as contact details, skills, education, and work experience. Natural language processing techniques
could be used to analyze the content of the resumes and rank them, helping employers quickly identify suitable
candidates.</p>             </ul>
            </div><!-- Edn Resume Item -->

            <div class="resume-item">
              <h3>Meet Summarization |NaturalLanguage Processing
              </h3>
              
              <ul>
                <p>A Meet Summarization project in Natural Language Processing (NLP) aims to automate the process of summarizing
discussions, meetings, or conversations conducted in audio or text format then automatically generate concise and
coherent summaries of meetings, discussions, or presentations, thereby saving time and improving information retention
for participants</p>    </ul>
            </div><!-- Edn Resume Item -->
            <div class="resume-item">
              <h3>Fruit-Vegetable Recognition + Calories Counter App | Machine Learning
              </h3>
              
              <ul>
                <p>This project allows users to capture or upload images of fruits and vegetables, recognize the items, and estimate their
                calorie counts and promoting healthy dietary choices</p>    </ul>
            </div><!-- Edn Resume Item -->
            </div>  
          
        <h3 class="resume-title"></h3>
           
           
 
           <p><em></em></p>
           
        </div>
      </div>

    </section><!-- /Resume Section -->
   
    <!-- Services Section -->
    <section id="Internship" class="services section">

      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <h2>Internship</h2>
        <h4>CodeClause ( Web Development Internship) </h4>
        <p>As a Web Development Intern at CodeClause ,I designed and implemented web-based software solutions. In this I
completed 2 basic project and 1 main project. This internship enhanced both frontend development skills, provided
practical web development experience and contributed to CodeClause's technological advancements</p>      </div><!-- End Section Title -->
      </div>

    </section><!-- /Services Section -->

    <!-- Contact Section -->
    <section id="contact" class="contact section">

      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <h2>Contact</h2>
      </div><!-- End Section Title -->

      <div class="container" data-aos="fade" data-aos-delay="100">

        <div class="row gy-4">

          <div class="col-lg-4">
            <div class="info-item d-flex" data-aos="fade-up" data-aos-delay="200">
              <i class="bi bi-geo-alt flex-shrink-0"></i>
              <div>
                <h3>Address</h3>
                <p><?php echo "$data[address]"?></p>
              </div>
            </div><!-- End Info Item -->

            <div class="info-item d-flex" data-aos="fade-up" data-aos-delay="300">
              <i class="bi bi-telephone flex-shrink-0"></i>
              <div>
                <h3>Call Us</h3>
                <p><?php echo "$data[phone]"?></p>
              </div>
            </div><!-- End Info Item -->

            <div class="info-item d-flex" data-aos="fade-up" data-aos-delay="400">
              <i class="bi bi-envelope flex-shrink-0"></i>
              <div>
                <h3>Email Us</h3>
                <p><?php echo "$data[email]"?></p>
              </div>
            </div><!-- End Info Item -->

          </div>

          <div class="col-lg-8">
            <form action="forms/contact.php" method="post" class="php-email-form" data-aos="fade-up" data-aos-delay="200">
              <div class="row gy-4">

                <div class="col-md-6">
                  <input type="text" name="name" class="form-control" placeholder="Your Name" required="">
                </div>

                <div class="col-md-6 ">
                  <input type="email" class="form-control" name="email" placeholder="Your Email" required="">
                </div>

                <div class="col-md-12">
                  <input type="text" class="form-control" name="subject" placeholder="Subject" required="">
                </div>

                <div class="col-md-12">
                  <textarea class="form-control" name="message" rows="6" placeholder="Message" required=""></textarea>
                </div>

                <div class="col-md-12 text-center">
                  <div class="loading">Loading</div>
                  <div class="error-message"></div>
                  <div class="sent-message">Your message has been sent. Thank you!</div>

                  <button type="submit">Send Message</button>
                </div>

              </div>
            </form>
          </div><!-- End Contact Form -->

        </div>

      </div>

    </section><!-- /Contact Section -->

  </main>

  <footer id="footer" class="footer light-background">
  <h1><?php echo "$data[name]"?></h1>
    <div class="container">
       <div class="social-links d-flex justify-content-center">
        
        
        <a href="<?php echo "$data[instagram]"?>"><i class="bi bi-instagram"></i></a>
        <a href="<?php echo "$data[github]"?>"><i class="bi bi-github"></i></a>
        <a href="<?php echo "$data[linkdin]"?>"><i class="bi bi-linkedin"></i></a>
      </div>
      <div class="container">
        <div class="copyright">
          <span>Copyright</span> <strong class="px-1 sitename"><?php echo "$data[name]"?></strong> <span>All Rights Reserved</span>
        </div>
        
      </div>
    </div>
  </footer>

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>
  <script>
    const toggleImage = document.getElementById('toggle-image');
    const body = document.body;
    const header = document.getElementById('header');
    const footer = document.getElementById('footer');
    const sections = document.querySelectorAll('.section');

    toggleImage.addEventListener('click', () => {
        body.classList.toggle('dark-mode');
        header.classList.toggle('dark-mode');
        footer.classList.toggle('dark-mode');
        sections.forEach(section => section.classList.toggle('dark-mode'));
        
        // Change the image based on the mode
        if (body.classList.contains('dark-mode')) {
            toggleImage.src = 'assets/img/icon.png';  // Change to light mode icon
        } else {
            toggleImage.src = 'assets/img/icon1.png';   // Change to dark mode icon
        }
    });

    // Set initial mode
    if (!body.classList.contains('dark-mode')) {
        body.classList.add('light-mode');
    }
</script>


</body>

</html>